import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'repositories/supabase_repository.dart';
import 'repositories/auth_repository.dart';
import 'screens/auth/login_screen.dart';
import 'screens/user/car_details_screen.dart';
import 'screens/user/home_screen.dart';
import 'screens/admin/admin_dashboard.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SupabaseRepository.initialize();
  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String? userRole;
  bool isLoggedIn = false;
  bool isChecking = true;

  @override
  void initState() {
    super.initState();
    _checkLoginStatus();
  }

  Future<void> _checkLoginStatus() async {
    try {
      final authRepo = AuthRepository();
      final user = await authRepo.getCurrentUser();
      await Future.delayed(const Duration(seconds: 1));
      setState(() {
        isLoggedIn = user != null;
        userRole = user?.role;
        isChecking = false;
      });
    } catch (e) {
      setState(() {
        isLoggedIn = false;
        userRole = null;
        isChecking = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bugatti Cars | بوقاتي كار',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.red,
        useMaterial3: true,
        fontFamily: 'Poppins',
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.red[700],
          elevation: 0,
          centerTitle: true,
        ),
      ),
      home: isChecking
          ? const SplashScreen()
          : isLoggedIn
              ? (userRole == 'admin'
                  ? const AdminDashboard()
                  : const UserHomeScreen())
              : const LoginScreen(),
      routes: {
  '/login': (context) => const LoginScreen(),
  '/home': (context) => const UserHomeScreen(),
  '/admin': (context) => const AdminDashboard(),
  '/car-details': (context) {
    final carId = ModalRoute.of(context)?.settings.arguments as int? ?? 0;
    return CarDetailsScreen(carId: carId);
  },
},
    );
  }
}

// شاشة التحميل
class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                color: Colors.red[700],
                borderRadius: BorderRadius.circular(25),
              ),
              child: const Icon(
                Icons.directions_car,
                size: 60,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 30),
            const Text(
              'Bugatti Cars',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const Text(
              'بوقاتي كار',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 50),
            const CircularProgressIndicator(),
          ],
        ),
      ),
    );
  }
}